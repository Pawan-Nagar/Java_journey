
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import your_package_name.DbClass;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Servlet implementation class ProcessApproval
 */
@WebServlet("/ProcessApproval")

public class ProcessApproval extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessApproval() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
        PrintWriter out = response.getWriter();

		 
		 
		 int id = Integer.parseInt(request.getParameter("id"));
		 System.out.println(request.getParameter("id"));
	     String status = request.getParameter("status");
	     String department = request.getParameter("department");
	     int n=0;
	    
		try {
			 n = DbClass.updateRequest(id, status);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if( n > 0) {
	 	if(department.equals("Legal")) {
			response.sendRedirect("legal.jsp");
		}
		else {
			response.sendRedirect("finance.jsp");

		}
	     }
	     else {
	    	 out.println("Error"); 
	     }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
