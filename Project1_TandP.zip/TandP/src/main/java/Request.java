import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import your_package_name.DbClass;

@WebServlet("/Request")
public class Request extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Request() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	int n = 0;
        // Handle form submission and database update
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String department = request.getParameter("department");
        PrintWriter out = response.getWriter();
        // Save the request to the database
        try {
			n = DbClass.saveRequestToDatabase(title, description, department);
			if(n>0) {
				response.sendRedirect("management.jsp");
			}
			else {
				out.println("unceesfully");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

     
    }
    
}
