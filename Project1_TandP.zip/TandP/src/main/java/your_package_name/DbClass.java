package your_package_name;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DbClass {

	public static Connection takeConnection()
	{
		Connection con = null;
		try
		{
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3000/myprojectjsp", "root", "IiTIAN");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return con;
	}
	 public static int saveRequestToDatabase(String title, String description, String department) throws SQLException {
		 PreparedStatement pstmt = null;
	       
	        	Connection conn = takeConnection();
	            String query = "INSERT INTO requests (request_title, request_description, target_department) VALUES (?, ?, ?)";
	              pstmt = conn.prepareStatement(query);
	                pstmt.setString(1, title);
	                pstmt.setString(2, description);
	                pstmt.setString(3, department);
	         
			return  pstmt.executeUpdate();

	    }
	 
	 public static int updateRequest(int id, String status) throws SQLException {
		    PreparedStatement pstmt = null;
		    Connection conn = takeConnection();

		  
		    String query = "UPDATE requests SET approval_status = ? WHERE id = ?";
		    pstmt = conn.prepareStatement(query);

		    pstmt.setString(1, status);
		    pstmt.setInt(2, id);
		  

		    return pstmt.executeUpdate();
		}

}
